function playBirthdaySong() {
  const audio = document.getElementById("birthdaySong");
  audio.play();
}
